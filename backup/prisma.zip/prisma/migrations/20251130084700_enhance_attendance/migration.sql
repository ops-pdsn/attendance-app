-- AlterTable
ALTER TABLE "Attendance" ADD COLUMN "punchIn" DATETIME;
ALTER TABLE "Attendance" ADD COLUMN "punchOut" DATETIME;
